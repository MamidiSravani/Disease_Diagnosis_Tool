from flask import Flask, render_template, request
import pickle

app = Flask(__name__)
def predict_disease(symptoms_list):
    try:
        with open('disease_predictor.pkl', 'rb') as f:
            data = pickle.load(f)
        
        model = data['model']
        label_encoder = data['label_encoder']
        all_symptoms = data['symptoms']
        
        input_vector = [1 if symptom in symptoms_list else 0 for symptom in all_symptoms]
        
        prediction = model.predict([input_vector])
        disease = label_encoder.inverse_transform(prediction)
        
        return disease[0]
    except FileNotFoundError:
        print("Model not found. Please train the model first.")
        return None

@app.route('/', methods=['GET', 'POST'])
def index():
    predicted = None
    if request.method == 'POST':
        user_input = request.form['symptoms']
        symptoms = [s.strip().lower() for s in user_input.split(',')]
        predicted = predict_disease(symptoms)
    return render_template('index.html', predicted=predicted)

if __name__ == '__main__':
    app.run(debug=True)
